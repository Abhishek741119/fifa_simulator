# Fifa-simulator
A Python Package for Simulation of fifa-like tournament fixtures

Following python statement is used to run the program
```
import fixtures
```
