#FIFA Simulator

A Python Package for Simulation of fifa-like tournament fixtures

#Running the program

Following python statements can be used...
```
import fifa_simulator.fixtures
      or
from fifa_simulator import fixtures